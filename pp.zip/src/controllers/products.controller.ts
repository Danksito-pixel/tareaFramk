import type { Request, Response } from "express";
import { pool } from "../conf/dbConnection.ts";

function readId(req: Request, res: Response): any {
    const value = req.params["id"];

    if (typeof value !== "string" || !/^\d+$/.test(value)) {
        res.status(400).json({
            message: "El ID debe ser un entero positivo."
        });
        return null;
    }

    const id = Number(value);

    if (!Number.isSafeInteger(id) || id <= 0) {
        res.status(400).json({
            message: "El ID debe ser un entero positivo."
        });
        return null;
    }

    return id;
}

function isObject(value: any): boolean {
    return typeof value === "object"
        && value !== null
        && !Array.isArray(value);
}

function validPrice(price: any): boolean {
    return typeof price === "number"
        && Number.isFinite(price)
        && price > 0
        && price <= 99999999.99
        && Math.abs(price * 100 - Math.round(price * 100)) < 0.000001;
}

function readProduct(body: any): any {
    if (!isObject(body)) return null;

    const { name, price, stock, description, brand, img } = body;

    if (
        typeof name !== "string"
        || name.trim().length === 0
        || name.trim().length > 50
    ) return null;

    if (!validPrice(price)) return null;

    if (
        !Number.isInteger(stock)
        || stock < 0
        || stock > 2147483647
    ) return null;

    if (
        typeof description !== "string"
        || description.trim().length === 0
        || description.trim().length > 500
    ) return null;

    if (
        brand !== undefined
        && brand !== null
        && (typeof brand !== "string" || brand.length > 100)
    ) return null;

    if (
        img !== undefined
        && img !== null
        && typeof img !== "string"
    ) return null;

    return {
        name: name.trim(),
        price,
        stock,
        description: description.trim(),
        brand: brand ?? null,
        img: img ?? null
    };
}

function invalidProduct(res: Response) {
    return res.status(400).json({
        message: "Datos inválidos: name y description son obligatorios; price debe ser un número positivo con máximo dos decimales; stock debe ser un entero no negativo."
    });
}

function notFound(res: Response) {
    return res.status(404).json({
        message: "Producto no encontrado o inactivo."
    });
}

function databaseError(res: Response) {
    return res.status(500).json({
        message: "No se pudo completar la operación con la base de datos."
    });
}

export async function getAllProducts(req: Request, res: Response) {
    const active = req.query["active"];

    if (
        active !== undefined
        && active !== "TRUE"
        && active !== "true"
    ) {
        return res.status(400).json({
            message: "Sólo se permite consultar active=TRUE."
        });
    }

    try {
        const [products]: any = await pool.execute(
            `SELECT id, name, price, stock, description, brand, img, active
             FROM products
             WHERE active = ?
             ORDER BY id`,
            [true]
        );

        return res.status(200).json(products);
    } catch {
        return databaseError(res);
    }
}

export async function getProductById(req: Request, res: Response) {
    const id = readId(req, res);
    if (id === null) return;

    try {
        const [products]: any = await pool.execute(
            `SELECT id, name, price, stock, description, brand, img, active
             FROM products
             WHERE id = ? AND active = ?`,
            [id, true]
        );

        if (products.length === 0) return notFound(res);

        return res.status(200).json(products[0]);
    } catch {
        return databaseError(res);
    }
}

export async function createProduct(req: Request, res: Response) {
    const product = readProduct(req.body);
    if (product === null) return invalidProduct(res);

    try {
        const [result]: any = await pool.execute(
            `INSERT INTO products
             (name, price, stock, description, brand, img, active)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                product.name,
                product.price,
                product.stock,
                product.description,
                product.brand,
                product.img,
                true
            ]
        );

        return res.status(201).json({
            message: "Producto creado.",
            id: result.insertId
        });
    } catch {
        return databaseError(res);
    }
}

export async function updateProductById(req: Request, res: Response) {
    const id = readId(req, res);
    if (id === null) return;

    const product = readProduct(req.body);
    if (product === null) return invalidProduct(res);

    try {
        const [result]: any = await pool.execute(
            `UPDATE products
             SET name = ?, price = ?, stock = ?,
                 description = ?, brand = ?, img = ?
             WHERE id = ? AND active = ?`,
            [
                product.name,
                product.price,
                product.stock,
                product.description,
                product.brand,
                product.img,
                id,
                true
            ]
        );

        if (result.affectedRows === 0) return notFound(res);

        return res.status(200).json({
            message: "Producto actualizado.",
            id
        });
    } catch {
        return databaseError(res);
    }
}

export async function deleteProductById(req: Request, res: Response) {
    const id = readId(req, res);
    if (id === null) return;

    try {
        const [result]: any = await pool.execute(
            `UPDATE products
             SET active = ?
             WHERE id = ? AND active = ?`,
            [false, id, true]
        );

        if (result.affectedRows === 0) return notFound(res);

        return res.status(200).json({
            message: "Producto dado de baja.",
            id
        });
    } catch {
        return databaseError(res);
    }
}

export async function changeProductPrice(req: Request, res: Response) {
    const id = readId(req, res);
    if (id === null) return;

    const body = req.body;

    if (
        !isObject(body)
        || Object.keys(body).length !== 1
        || !validPrice(body.price)
    ) {
        return res.status(400).json({
            message: "Envía únicamente price: un número positivo con máximo dos decimales y no mayor que 99999999.99."
        });
    }

    try {
        const [result]: any = await pool.execute(
            `UPDATE products
             SET price = ?
             WHERE id = ? AND active = ?`,
            [body.price, id, true]
        );

        if (result.affectedRows === 0) return notFound(res);

        return res.status(200).json({
            message: "Precio actualizado.",
            id,
            price: body.price
        });
    } catch {
        return databaseError(res);
    }
}