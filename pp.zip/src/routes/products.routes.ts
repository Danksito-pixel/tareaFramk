import { Router } from "express";
import {
    getAllProducts,
    getProductById,
    createProduct,
    updateProductById,
    deleteProductById,
    changeProductPrice
} from "../controllers/products.controller.ts";

const router = Router();

router.get("/getAll", getAllProducts);
router.get("/getById/:id", getProductById);
router.post("/create", createProduct);
router.put("/update/:id", updateProductById);
router.delete("/delete/:id", deleteProductById);
router.patch("/change-price/:id", changeProductPrice);

export default router;