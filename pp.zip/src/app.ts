import "dotenv/config";
import { createServer } from "./server.ts";
import routes from "./routes/index.ts";

const port = Number(process.env.PORT ?? 3000);

if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error("PORT debe ser un entero entre 1 y 65535.");
}

const app = createServer(routes);

app.listen(port, () => {
    console.log(`API de productos lista en http://localhost:${port}`);
});