import express from "express";

export function createServer(routes: any) {
    const app = express();

    app.use(express.json());
    app.use("/", routes);

    return app;
}